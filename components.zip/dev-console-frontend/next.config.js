/** @type {import('next').NextConfig} */
const nextConfig = {
  // swcMinify: true,
  reactStrictMode: true,
  images: {
    domains: ['cdn.hireez.com', 'cdn.testhtm.com', 'images.unsplash.com'],
  },
  env: {
    HIRETUAL_CDN_URL: process.env.HIRETUAL_CDN_URL,
  },
}

module.exports = nextConfig
