module.exports = {
  tailwindConfig: './styles/tailwind.config.js',
}
